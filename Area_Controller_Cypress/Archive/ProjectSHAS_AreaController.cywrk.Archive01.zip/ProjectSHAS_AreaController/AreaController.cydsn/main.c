/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdlib.h"

char commandBytes[10] = "";
uint8 curCount,IntSteps,IntRGB,readyStatus = 0;

CY_ISR(Rx_ISR_Call) {
    char curChar = UART_1_GetChar();
    if (curChar >= 'A' && curChar <='Z') {
        UART_1_PutChar(curChar);
        commandBytes[curCount] = curChar;
        curCount++;
    } else {
        
        uint8 IntReset = 0;
        for (IntReset = 0; IntReset < 4; IntReset++) {
                
        }
        curCount = 0;
        readyStatus = 1;
        UART_1_PutString( "\r\n" );
    }
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    RxISR_StartEx(Rx_ISR_Call);

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    UART_1_Start(); //Start UART
    UART_1_PutString( "Starting Stepper :3\r\n" );
    uint16 i,k = 0;
    RGB_OUT_Write(70);
    for(;;)
    {
        /* Stepper Motor Example */
        if (readyStatus == 1) {
            // Change LED States
            RGB_OUT_Write(IntRGB);
            // Change Stepper State
            if (k != IntSteps) {
                STEP_EN_Write(1);
                STEP_DIR_Write(1);
                for(i = 1; i<=IntSteps; i++) {
                    STEP_RUN_Write(1);
                    STEP_RUN_Write(0);
                    CyDelay(15);
                }
                STEP_EN_Write(0);
            }
            readyStatus = 0;
            STEP_EN_Write(0);
        }
//        CyDelay(250);
      //  itoa(i, NumSteps, 10);
        //UART_1_PutString( "Pururin~ " );
        //UART_1_PutString( NumSteps );
        //UART_1_PutString( "\r\n" );
        //i++;
        //CyDelay(1000);
        
    }
}

/* [] END OF FILE */
